package com.example.a111p_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edit;
    Button btn1, btn2;
    String add;
    RadioButton Rbtn2;
//    RadioGroup Rgp;
    ImageView img;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.drawable.ic_launcher);
        setTitle("좀 그럴듯한 앱");

        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        edit = (EditText) findViewById(R.id.edit);
        Rbtn2=(RadioButton) findViewById(R.id.Rbtn2);
//        Rgp=(RadioGroup)findViewById(R.id.Rgp);
        img=(ImageView)findViewById(R.id.img);

        btn1.setBackgroundColor(Color.LTGRAY);
        btn2.setBackgroundColor(Color.GRAY);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add = edit.getText().toString();
                Toast.makeText(getApplicationContext(),add,
                        Toast.LENGTH_SHORT).show();
            };
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent mlntent = new Intent(Intent.ACTION_VIEW, Uri.parse(add));
                startActivity(mlntent);
            };
        });

        img.setImageResource(R.drawable.kakao);

        Rbtn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                img.setImageResource(R.drawable.ic_launcher);

                }

        });
    }
}
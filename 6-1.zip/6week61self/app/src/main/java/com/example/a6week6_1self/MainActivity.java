package com.example.a6week6_1self;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Chronometer;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;

public class MainActivity extends AppCompatActivity {
    RadioButton cal,time;
    RadioGroup rg;
    Chronometer chro;
    DatePicker  datep;
    TimePicker timep;
    TextView    year;

    int selectedYear,selectedMonth,selectedDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("시간 예약");

        cal=(RadioButton)findViewById(R.id.cal);
        time=(RadioButton)findViewById(R.id.time);
        chro=(Chronometer)findViewById(R.id.chro);
        datep=(DatePicker) findViewById(R.id.datep);
        timep=(TimePicker)findViewById(R.id.timep);
        year=(TextView)findViewById(R.id.year);
        rg=(RadioGroup)findViewById(R.id.rg);


        rg.setVisibility(View.INVISIBLE);
        datep.setVisibility(View.INVISIBLE);
        timep.setVisibility(View.INVISIBLE);


        chro.setOnClickListener(new View. OnClickListener(){
            @Override
            public void onClick(View view) {
                rg.setVisibility(View.VISIBLE);
                chro.setBase(SystemClock.elapsedRealtime());
                chro.start();
                chro.setTextColor(Color.RED);
            };
        });

        cal.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                datep.setVisibility(View.VISIBLE);
                timep.setVisibility(View.INVISIBLE);
            }
        });

        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datep.setVisibility(View.INVISIBLE);
                timep.setVisibility(View.VISIBLE);
            }
        });



        year.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                chro.stop();
                chro.setTextColor(Color.BLUE);

                selectedYear=datep.getYear();
                selectedMonth=datep.getMonth();
                selectedDay=datep.getDayOfMonth();

                String result=selectedYear+"년"+selectedMonth+"월"+selectedDay+"일";
                result+=timep.getCurrentHour()+"시"+timep.getCurrentMinute()+"분 예약됨";

                year.setText(result);

                rg.setVisibility(View.INVISIBLE);
                datep.setVisibility(View.INVISIBLE);
                timep.setVisibility(View.INVISIBLE);

                return false;

            }
        });


    }
}
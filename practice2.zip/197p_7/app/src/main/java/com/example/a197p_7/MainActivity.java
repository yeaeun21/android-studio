package com.example.a197p_7;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    CheckBox  enabled,clickable,turn;
    Button  tbtn;
    int i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("연습문제 4-7");

        enabled = (CheckBox) findViewById(R.id.enaled);
        clickable = (CheckBox) findViewById(R.id.clickable);
        turn = (CheckBox) findViewById(R.id.turn);
        tbtn = (Button) findViewById(R.id.tbtn);


        tbtn.setBackgroundColor(Color.GRAY);

        while(i<=5) {
            turn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {


                    if (enabled.isChecked() == true) {

                        tbtn.setRotation((float) 45);

                    } else if (clickable.isChecked() == true) {

                        tbtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                tbtn.setRotation((float) 45);
                            }

                            ;
                        });
                    } else if (enabled.isChecked() != true || clickable.isChecked() != true) {
                        tbtn.setRotation((float) 0);

                    };
                };
            });
            i += 1;
        };
    };
}
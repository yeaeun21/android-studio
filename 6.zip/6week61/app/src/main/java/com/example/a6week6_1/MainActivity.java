package com.example.a6week6_1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Chronometer;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.TimePicker;

public class MainActivity extends AppCompatActivity {
    Button btn,btn2;
    RadioButton cal,time;
    Chronometer chro;
    CalendarView  calen;
    TimePicker timep;
    TextView    year;
    int selectedYear,selectedMonth,selectedDay;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("시간 예약");

        btn=(Button)findViewById(R.id.btn);
        btn2=(Button)findViewById(R.id.btn2);
        cal=(RadioButton)findViewById(R.id.cal);
        time=(RadioButton)findViewById(R.id.time);
        chro=(Chronometer)findViewById(R.id.chro);
        calen=(CalendarView) findViewById(R.id.calen);
        timep=(TimePicker)findViewById(R.id.timep);
        year=(TextView)findViewById(R.id.year);


        btn.setBackgroundColor(Color.GRAY);
        btn2.setBackgroundColor(Color.GRAY);


        calen.setVisibility(View.INVISIBLE);
        timep.setVisibility(View.INVISIBLE);
        year.setVisibility(View.INVISIBLE);

        btn.setOnClickListener(new View. OnClickListener(){
            @Override
            public void onClick(View view) {
                chro.setBase(SystemClock.elapsedRealtime());
                chro.start();
                chro.setTextColor(Color.RED);
            };
        });

        cal.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                calen.setVisibility(View.VISIBLE);
                timep.setVisibility(View.INVISIBLE);
            }
        });

        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calen.setVisibility(View.INVISIBLE);
                timep.setVisibility(View.VISIBLE);
            }
        });



        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                year.setVisibility(View.VISIBLE);
                chro.stop();
                chro.setTextColor(Color.BLUE);

//                year.setText(Integer.toString(selectedYear));

                String result=selectedYear+"년"+selectedMonth+"월"+selectedDay+"일";
                result+=timep.getCurrentHour()+"시"+timep.getCurrentMinute()+"분 예약됨";

                year.setText(result);
            }
        });

        calen.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view,int year, int month, int dayOfMonth) {
                selectedYear = year;
                selectedMonth=month+1;
                selectedDay=dayOfMonth;
            }
        });


    }
}